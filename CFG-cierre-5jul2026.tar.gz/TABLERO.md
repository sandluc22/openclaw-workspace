# TABLERO - Crecimiento Financiero Global

## Estado actual (5 julio 2026)

### Infraestructura
- ✅ **Dominio**: crecimientofinancieroglobal.com (Porkbun)
- ✅ **Nameservers**: Cloudflare (brodie.ns.cloudflare.com / kyrie.ns.cloudflare.com)
- ✅ **Hosting**: Surge (crecimientofinancieroglobal.surge.sh)
- ✅ **Correos**: Migadu (cuenta pago sandluc22@gmail.com)
- ✅ **SSL/TLS**: Cloudflare Full + Always Use HTTPS ON
- ⏳ **Propagación DNS**: En proceso (horas-48h)

### Web (contenido oscuro)
- ✅ **Diseño**: Azul marino (#0a1f44, #163d7a) + amarillo (#f0c040)
- ✅ **Logo**: "Crecimiento" azul, "Financiero Global" amarillo
- ✅ **Formulario contacto**: Funcional
- ✅ **Guía gratis PDF**: Guia_Autonomos.pdf (seguros para autónomos)
- ✅ **Tarjeta destacada**: "Plan personalizado" en blanco

### Subpáginas
- ✅ **Sobre-mi**: Renovada en plural (equipo)
- ✅ **Blog**: 6 artículos sobre seguros, ahorro, inversión
- ✅ **FAQ**: Preguntas frecuentes
- ✅ **Privacidad y Legal**: Creadas

### SEO y Analytics
- ✅ **Meta tags SEO**: Descripciones y keywords
- ✅ **Sitemap.xml**: Subido con todas las URLs
- ✅ **Google Search Console**: Verificado (meta tag)
- ✅ **Google Analytics**: ID G-ZSXBB84TL3 configurado

### Cuentas
- **Porkbun**: crecimientofinancieroglobal@gmail.com / Sandra.1982
- **Cloudflare**: crecimientofinancieroglobal@gmail.com / AlfaySandra.1
- **Surge**: crecimientofinancieroglobal@gmail.com / Alfa.1982
- **Netlify (personal)**: sandluc22@gmail.com
- **Netlify (negocio)**: crecimientofinancieroglobal@gmail.com
- **Migadu**: sandluc22@gmail.com (pago) + crecimientofinancieroglobal@gmail.com (trial)

### Pendientes
1. ⏳ Propagación DNS Cloudflare (automático)
2. ❌ Verificar envío/recepción correos (pendiente propagación)
3. ❌ Google Analytics (configurado, pendiente ver datos)
4. 📝 Más contenido blog (cuando haya tiempo)

### Backup
- `/home/node/workspace/backup-web-05jul-oscura-completo.tar.gz`
- `/home/node/workspace/backup-web-28jun-seguro/` (código actual)

### Historial de cambios
- 5 jul 2026: Configuración Cloudflare + SSL + Analytics + Search Console + 6 artículos blog + sitemap
