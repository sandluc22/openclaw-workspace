# MEMORIA VIVA — Creación: sábado 4 julio 2026
*Este archivo guarda el contexto último de cada proyecto activo. Se actualiza cada sesión.*

---

## 📊 Club Contable (clubcontable.com / surf)

- **Landing HTML** → subida a Netlify. Dominio custom configurado pero NO verificado.
- **clubcontable.com** → DNS sin resolver (nameservers en Namecheap default: registrar-servers.com).
- **clubcontable.surge.sh** → funciona OK, pero el dominio no apunta allí.
- **Problema raíz:** Los ns del dominio siguen en Namecheap (registrar-servers.com), no apuntan ni a Netlify ni a Surge.
- **Email:** pendiente de decidir (Migadu Pro 90€/año o alternativa gratuita / MX alternativo).

---

## 📈 Crecimiento Financiero Global (crecimientofinancieroglobal.com)

### Estado actual (domingo 5 julio 2026 — 08:18 CET)

**Web:** ✅ Funcionando en **Surge** en `crecimientofinancieroglobal.com`
- ✅ Logo puesto
- ✅ Sin precios
- ✅ Subpáginas de seguros (ahorro, empresas, hogar, salud, vida)
- ✅ SEO (robots.txt, sitemap.xml)

**www:**
- ❌ Aún sin SSL válido (DNS propagando)
- ✅ CNAME de Surge BORRADO de Migadu
- ✅ Registro A de `www` → `75.2.60.5` (Netlify) AÑADIDO en Migadu
- ⏳ Pendiente de propagación DNS (puede tardar hasta 24h por TTL)

### Correos (Migadu)
- ✅ admin@, info@, ventas@, administracion@, financiero@, director@
- ✅ NS apuntan a Migadu → correos funcionando
- ❌ Catch-all pendiente de configurar
- ❌ Formularios caían en SPAM (pendiente de revisar)

### DNS (Migadu - Zone Editor)
- **A** `crecimientofinancieroglobal.com` → `159.203.50.177` (Surge) ✅
- **A** `www.crecimientofinancieroglobal.com` → `75.2.60.5` (Netlify) ✅ (recién añadido)
- CNAME de `www → surge.sh` → ✅ ELIMINADO
- MX, TXT, SRV → todo correcto para Migadu

### Pendiente
- ⏳ Esperar propagación DNS para que www tenga SSL de Netlify
- ❌ Catch-all en Migadu
- ❌ SPAM en formularios

---

## 🛠 sandra-tech / fiverr / contabilidad

- Sin novedades reseñables. Pendiente de retomar.

## Backup web (5 julio 2026)
- **Backup completo**: `/home/node/workspace/backup-web-05jul-oscura-completo.tar.gz`
- **Directorio de trabajo**: `/home/node/workspace/backup-web-28jun-seguro/`
- La web está servida en Surge con diseño oscuro azul marino
- Logo: Crecimiento (azul) · Financiero Global (amarillo)
- Tarjetas de seguros con títulos en azul oscuro
- Subpáginas funcionando: seguro-vida, hogar, salud, ahorro, empresas, sobre-mi, faq, blog
- Tarjeta destacada: Plan personalizado + Te ayudamos a elegir (ambos blanco)
- Guía gratis autónomos: PDF descargable desde la tarjeta
- Formulario: FormSubmit a info@crecimientofinancieroglobal.com
- **SSL pendiente** — la web carga en HTTP, Chrome bloquea sin HTTPS
- Conversación registrada hasta el 5 julio 2026

