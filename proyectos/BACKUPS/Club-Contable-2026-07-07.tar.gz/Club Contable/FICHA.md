# 📋 FICHA TÉCNICA — Club Contable

**Propietaria:** Sandra Caicedo
**Última actualización:** 06-jul-2026

---

## 🌐 1. DOMINIO

| Dato | Valor |
|---|---|
| **Dominio** | clubcontable.com |
| **Registrado en** | 🔒 **Namecheap** |
| **Usuario Namecheap** | sandluc22 |
| **Contraseña Namecheap** | AlfaySandra. |
| **Fecha de creación** | ⚠️ Pendiente de consultar |
| **Fecha de expiración** | ⚠️ Pendiente de consultar |
| **Precio/año** | ⚠️ Pendiente de consultar |

---

## 🚀 2. HOSTING

| Plataforma | Estado | URL |
|---|---|---|
| **Netlify** | ⏳ Site creado, sin contenido | clubcontable.netlify.app |
| **Netlify Site ID** | ⚠️ Pendiente de consultar | |

**Acceso Netlify:** crecimientofinancieroglobal@gmail.com / Slch12345+ (login Google)
**Dashboard:** https://app.netlify.com

---

## 📧 3. CORREOS

| Cuenta | Estado | Notas |
|---|---|---|
| **info@clubcontable.com** | ❌ Pendiente de configurar | El dominio está en Namecheap pero no hay correo asociado aún |
| **crecimientofinancieroglobal@gmail.com** | ✅ Cuenta de gestión general | Contraseña: Slch12345+ |

**Recomendación:** Usar Migadu (misma cuenta de pago que CFG) o Gmail Workspace para los correos.

---

## 🆔 4. DNS / NAMESERVERS

| Consulta | Estado |
|---|---|
| **DNS** | ⏳ En Namecheap (no configurados aún) |
| **Nameservers** | Pendiente de definir según hosting |
| **IP** | Pendiente de definir |

---

## 🛠️ 5. SERVICIOS TÉCNICOS

| Servicio | Estado |
|---|---|
| **SSL** | ⏳ Pendiente (Netlify lo da gratis) |
| **Google Analytics** | ❌ No configurado |
| **Search Console** | ❌ No configurado |
| **Sitemap** | ❌ No creado |
| **Contenido web** | ❌ No hay aún |

---

## 💰 6. PRESUPUESTO / COSTES

| Servicio | Coste | Frecuencia | Próximo pago |
|---|---|---|---|
| **Namecheap (clubcontable.com)** | ⚠️ Pendiente | Anual | ⚠️ Pendiente |
| **Netlify** | Gratis | — | — |

---

## ⏰ 7. FECHAS DE CADUCIDAD

| Servicio | Fecha | Alerta |
|---|---|---|
| **Dominio Namecheap** | ⚠️ Pendiente | No configurada |

---

## 🔄 8. ESTADO DEL DEPLOY

| Aspecto | Valor |
|---|---|
| **Último deploy** | ❌ Ninguno |
| **Versión en producción** | ❌ No hay |
| **Código fuente** | ❌ No hay |
| **Backup disponible** | ❌ No hay |

---

## 🛟 9. INSTRUCCIONES DE RECUPERACIÓN

El proyecto está en fase inicial. No hay nada que recuperar aún.

---

## 📞 10. SOPORTE TÉCNICO

| Servicio | Contacto |
|---|---|
| **Namecheap** | https://www.namecheap.com/support/ |
| **Netlify** | https://www.netlify.com/support/ |

---

## 📝 11. REGISTRO DE CAMBIOS

| Fecha | Cambio |
|---|---|
| **05/06-jul-2026** | Creación del proyecto. Dominio comprado en Namecheap. Site creado en Netlify. Sin contenido aún. |

---

## 📁 12. ARCHIVOS DEL PROYECTO

| Archivo | Ruta |
|---|---|
| **Ficha técnica (este archivo)** | `/home/node/workspace/proyectos/Club Contable/FICHA.md` |
| **Ficha en PDF** | `/home/node/workspace/proyectos/Club Contable/FICHA_Club_Contable.pdf` |

---

## ⚠️ 13. TAREAS PENDIENTES

- [ ] Consultar fecha de expiración del dominio en Namecheap
- [ ] Verificar cuánto cuesta la renovación del dominio
- [ ] Decidir plataforma de hosting (Netlify ya tiene site creado)
- [ ] Crear la web de Club Contable
- [ ] Configurar DNS de Namecheap
- [ ] Configurar correos info@clubcontable.com
- [ ] Verificar dominio en Google Search Console
- [ ] Configurar Google Analytics

---

## 🔐 14. CONTRASEÑAS

| Sitio | Email | Contraseña |
|---|---|---|
| **Namecheap** | sandluc22 | AlfaySandra. |
| **Netlify** | crecimientofinancieroglobal@gmail.com | Slch12345+ (login Google) |
| **Gmail gestión** | crecimientofinancieroglobal@gmail.com | Slch12345+ |

---

## 📌 NOTAS

- Usa la misma cuenta de Netlify y Gmail que CFG para simplificar la gestión
- El dominio ya está comprado, no hay que pagarlo otra vez
- Namecheap usa sandluc22 como usuario (no email)
