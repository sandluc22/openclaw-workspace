# 📋 FICHA TÉCNICA — Fiverr

**Propietaria:** Sandra Caicedo
**Última actualización:** 06-jul-2026

---

## 🌐 1. DOMINIO

| Dato | Valor |
|---|---|
| **Dominio** | ❌ Ninguno registrado |
| **Estado** | Sin definir |

---

## 🚀 2. HOSTING

| Plataforma | Estado |
|---|---|
| **Ninguno** | ❌ No hay hosting contratado |

---

## 📧 3. CORREOS

| Cuenta | Estado |
|---|---|
| **crecimientofinancieroglobal@gmail.com** | ✅ Cuenta de gestión general (Slch12345+) |

---

## 🛠️ 4. SERVICIOS TÉCNICOS

| Servicio | Estado |
|---|---|
| **Web** | ❌ No hay proyecto web iniciado |
| **SSL** | ❌ No aplica |
| **Analytics** | ❌ No aplica |
| **Search Console** | ❌ No aplica |

---

## 💰 5. PRESUPUESTO

| Servicio | Coste |
|---|---|
| **Ninguno** | 0 € |

---

## 🔄 6. ESTADO DEL DEPLOY

| Aspecto | Valor |
|---|---|
| **Web en producción** | ❌ No hay |
| **Código fuente** | ❌ No hay |
| **Backup** | ❌ No hay |

---

## 🛟 7. INSTRUCCIONES DE RECUPERACIÓN

No aplica. Proyecto sin iniciar.

---

## 📝 8. REGISTRO DE CAMBIOS

| Fecha | Cambio |
|---|---|
| **06-jul-2026** | Creación del proyecto. Sin contenido aún. |

---

## 📁 9. ARCHIVOS DEL PROYECTO

| Archivo | Ruta |
|---|---|
| **Ficha técnica (este archivo)** | `/home/node/workspace/proyectos/Fiverr/FICHA.md` |
| **Ficha en PDF** | `/home/node/workspace/proyectos/Fiverr/FICHA_Fiverr.pdf` |

---

## ⚠️ 10. TAREAS PENDIENTES

- [ ] Definir qué proyecto/servicio de Fiverr se va a desarrollar
- [ ] Comprar dominio si es necesario
- [ ] Elegir hosting
- [ ] Crear contenido web

---

## 🔐 11. CONTRASEÑAS

| Sitio | Email | Contraseña |
|---|---|---|
| **Gmail gestión** | crecimientofinancieroglobal@gmail.com | Slch12345+ |

---

## 📌 NOTAS

- Proyecto pendiente de definir. Cuando se decida, usar la misma cuenta de Gmail para gestión.
