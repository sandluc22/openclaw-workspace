# FICHA TÉCNICA - Crecimiento Financiero Global (CFG)

## 1. Dominio
- **URL:** crecimientofinancieroglobal.com
- **Registrador:** Porkbun
- **Caducidad:** 23-jun-2027 (auto-renovación activada)
- **Estado:** ✅ Funcionando

## 2. DNS
- **Gestionados por:** Cloudflare
- **NS en Porkbun:** chase.ns.cloudflare.com, sima.ns.cloudflare.com
- **Registro A:** crecimientofinancieroglobal.com → 188.166.132.94 (Surge)
- **Registro A:** api.crecimientofinancieroglobal.com → 13.140.159.236 (proxy naranja ☁️)
- **CNAME:** www → crecimientofinancieroglobal.surge.sh
- **Proxy Cloudflare:** Activado (naranja) para el dominio principal

## 3. Hosting
- **Activo:** Surge (crecimientofinancieroglobal.surge.sh)
- **Código fuente:** /home/node/workspace/cfg-restauracion/ (25 archivos)
- **Carpeta deploy:** /home/node/workspace/deploy-cfg-limpio/ (12 archivos)
- **Alternativa:** Netlify (zip preparado en deploy-netlify.zip - 148KB, 22 archivos)

## 4. Correos
- **Gestor:** Migadu
- **Email principal:** info@crecimientofinancieroglobal.com
- **Configuración SMTP pendiente:** contraseña del mailbox info@ no verificada

## 5. Google Analytics
- **ID:** G-ZSXBB84TL3 (GA4)
- **Estado:** ✅ Instalado en index.html y subpáginas

## 6. Google Search Console
- **Estado:** ✅ Configurado (verificado via Cloudflare DNS)

## 7. Sitemap / Robots
- **Sitemap:** /sitemap.xml ✅
- **Robots.txt:** /robots.txt ✅ (permite todo, apunta a sitemap)

## 8. Formulario de contacto
- **Método actual:** FormSubmit.co → info@ (los emails llegan)
- **Problema:** Kaspersky muestra aviso de seguridad "no es seguro enviar datos"
- **Backend alternativo:** Node.js + Express en servidor AWS (13.140.159.236:3000)
- **Endpoint backend:** /api/contacto (recibe POST JSON, reenvía a Telegram de Sandra)
- **Endpoint prueba:** /api/health
- **Reporte diario:** Programado a las 22:00 España (node-cron)
- **Estado del túnel:** ❌ No activo (localhost.run inestable, serveo caído)
- **Pendiente:** Desplegar backend en Railway/Render/Netlify o autorizar Google Apps Script

## 9. Contenido web actual
- **Index principal:** Hero con CTA a formulario + servicios (4 cards) + blog + contacto
- **Subpáginas con contenido SEO (creadas jul 2026):**
  - seguro-salud/index.html (~900 palabras)
  - seguro-vida/index.html (~900 palabras)  
  - ahorro-inversion/index.html (~900 palabras)
  - empresas-autonomos/index.html (~900 palabras)
- **Artículos de blog (creados jul 2026):**
  - seguro-salud-guia-completa.html (~500 palabras)
  - seguro-vida-mitos-realidades.html (~500 palabras)
  - ahorro-inversion-primeros-pasos.html (~500 palabras)
  - proteccion-empresas-autonomos.html (~500 palabras)
- **Páginas adicionales:** sobre-mi.html, faq.html, gracias.html

## 10. Último deploy
- **Fecha:** 6-jul-2026 (14:40h España)
- **Host:** Surge
- **Contenido:** Todo el contenido SEO de subpáginas + blog + text-shadow en amarillo
- **Pendiente de actualizar:** Formulario funcional sin avisos de seguridad

## 11. Backups
- **Script backup:** /home/node/workspace/.backup-diario.sh
- **Horario:** 23:00 hora España (UTC+2)
- **Destino:** /home/node/workspace/proyectos/BACKUPS/
- **Formato:** CFG-YYYY-MM-DD.tar.gz
- **Limpieza:** automática >30 días
- **Último backup:** CFG-2026-07-06.tar.gz

## 12. Tareas pendientes
- [ ] **PRIORIDAD: Arreglar formulario** — El aviso de Kaspersky espanta clientes
- [ ] Desplegar backend Node.js en Railway/Render (cuando Sandra pueda hacer login)
- [ ] O autorizar Google Apps Script (cuando Sandra pueda acceder a script.google.com)
- [ ] O arrastrar carpeta de Netlify (cuando Sandra esté en su casa)
- [ ] Añadir Google My Business (que lo haga Sandra)

## 13. Contraseñas
- **Cloudflare:** AlfaySandra.1
- **Surge:** Alfa.1982
- **Porkbun:** Sandra.1982
- **Migadu (panel):** AlfaySandra!
- **Gmail CFG:** Slch12345+
- **Netlify:** Slch12345+

