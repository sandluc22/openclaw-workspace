# FICHA TÉCNICA - Crecimiento Financiero Global (CFG)

## 1. Dominio
- **URL:** crecimientofinancieroglobal.com
- **Registrador:** Porkbun
- **Caducidad:** 23-jun-2027 (auto-renovación activada)
- **Estado:** ✅ Funcionando

## 2. DNS
- **Gestionados por:** Cloudflare
- **NS en Porkbun:** chase.ns.cloudflare.com, sima.ns.cloudflare.com
- **Estado:** ✅ Activados (propagados globalmente)
- **Proxy:** Naranja (SSL gratuito vía Cloudflare)
- **A record @** → 75.2.60.5 (Netlify, proxy naranja)

## 3. Hosting
- **Servicio:** Netlify
- **URL directa:** https://6a4d6f12b35ba94756643174--crecimientofinancieroglobal.netlify.app
- **URL producción:** https://crecimientofinancieroglobal.com
- **SSL:** ✅ Google Trust Services (vía Cloudflare, válido hasta 25-sep-2026)
- **Site ID:** `937397ab-3157-469a-a8f4-7305963713dc`
- **Email Netlify:** crecimientofinancieroglobal@gmail.com
- **Token Netlify activo:** nfp_YEHGmHDD38cdGz3ivUFC6o9obMxa4uZE29e0 (expira 16-jul-2026)
- **Último deploy manual:** 09-jul a las 22:54 (Sandra desde su PC)

## 4. Correos
- **Gestor:** Migadu
- **Email principal:** info@crecimientofinancieroglobal.com ✅
- **Otros:** admin@, ventas@, administracion@, financiero@, director@
- **Estado:** ✅ Funcionando (MX en Cloudflare)

## 5. SEO y Visibilidad

### ✅ Completado
- **robots.txt:** ✅ Permite Googlebot, bloquea bots IA (GPTBot, ClaudeBot, etc.), apunta a sitemap
- **sitemap.xml:** ✅ Actualizado con **15 URLs** — incluye blog, artículos, páginas legales
- **SSL:** ✅ Google Trust Services
- **SEO básico:** Title, meta description, OG tags, canonical — todo correcto
- **Velocidad:** HTTP/2 + Cloudflare CDN con caché

### ❌ Pendiente
- **Google Search Console:** No configurado aún
  - Usar cuenta: `crecimientofinancieroglobal@gmail.com`
  - Enviar sitemap: `https://crecimientofinancieroglobal.com/sitemap.xml`
- **Google Analytics:** Ya configurado (GA4, G-ZSXBB84TL3)
- **Indexación Google:** Pendiente

## 6. Diseño
- **Estilo:** Oscuro azul marino (#0a1f44)
- **Logo:** Icono en azul marino + texto "Crecimiento" (azul) · "Financiero Global" (naranja #f97316)
- **Color principal:** 🟠 **Naranja** (#f97316) — cambiado de amarillo el 09-jul-2026
- **Formulario:** Nombre, Teléfono, Email, Fecha de nacimiento, Aseguradora de interés (desplegable), Seguro solicitado

## 7. Aseguradoras en desplegable
Sanitas, Adeslas, Asisa, Mapfre, DKV, AXA, Allianz, Generali, Caser, Reale, Aegon, Otra, No lo sé todavía

## 8. Formulario
- **action:** `form.php` (método POST)
- **Destino:** info@crecimientofinancieroglobal.com
- **Archivo:** `/home/node/workspace/proyectos/CFG/form.php`
- **Estado:** ✅ Configurado, pendiente de confirmar que está en el deploy de Netlify

## 9. Archivos del proyecto
- **Localización:** `/home/node/workspace/proyectos/CFG/`
- **`index.html`** — página principal (naranja, formulario completo)
- **`form.php`** — backend del formulario (envío a info@)
- **`sitemap.xml`** — 15 URLs con prioridades y lastmod
- **Copia backup:** `/home/node/workspace/index_cfg.html`

## 10. Despliegue temporal (para descarga)
- **URL:** https://descargar-cfg.surge.sh/index.html (archivo actualizado completo)
- **Cuenta Surge:** sandluc22@gmail.com (plan Student, 1 dominio)

## 11. Historial de trabajo (09-jul-2026)
- Mañana: Cambios color naranja + formulario con Fecha nacimiento y desplegable aseguradoras
- Tarde: Sandra desde su PC intenta subir a Netlify (archivo se descarga con nombre raro)
- Noche: Varios intentos de deploy vía API con tokens de Netlify (fallaron por permisos)
- 22:54h: Sandra sube manualmente el index.html a Netlify desde su ordenador personal
- Pendiente: Verificar que Cloudflare sirve la versión nueva

---

**Última actualización:** 09-jul-2026 23:02h
