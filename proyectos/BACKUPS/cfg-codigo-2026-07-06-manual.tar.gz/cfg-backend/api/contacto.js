// Serverless function para Vercel
const nodemailer = require('nodemailer');

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Método no permitido' });
  }
  
  try {
    const { nombre, email, telefono, mensaje } = req.body;
    
    if (!nombre || !email || !mensaje) {
      return res.status(400).json({ 
        success: false, 
        message: 'Faltan campos obligatorios' 
      });
    }
    
    const transporter = nodemailer.createTransport({
      host: 'smtp.migadu.com',
      port: 587,
      secure: false,
      auth: {
        user: 'info@crecimientofinancieroglobal.com',
        pass: 'AlfaySandra.'
      }
    });
    
    await transporter.sendMail({
      from: '"Web CFG" <info@crecimientofinancieroglobal.com>',
      to: 'info@crecimientofinancieroglobal.com',
      replyTo: email,
      subject: `Contacto web - ${nombre}`,
      html: `
        <h2>Nuevo mensaje desde crecimientofinancieroglobal.com</h2>
        <p><strong>Nombre:</strong> ${nombre}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Teléfono:</strong> ${telefono || 'No indicado'}</p>
        <p><strong>Mensaje:</strong></p>
        <p>${mensaje}</p>
      `
    });
    
    res.json({ success: true, message: 'Mensaje enviado correctamente' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al enviar' });
  }
};
