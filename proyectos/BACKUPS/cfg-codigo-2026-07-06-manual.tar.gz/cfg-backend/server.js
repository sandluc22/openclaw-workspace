const express = require('express');
const cors = require('cors');
const https = require('https');
const cron = require('node-cron');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 3000;
const BOT_TOKEN = '818137…iZWs';
const CHAT_ID = '7890204626';
let contactosHoy = [];
let totalContactos = 0;

function sendToTelegram(text) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify({ chat_id: CHAT_ID, text: text });
    const options = {
      hostname: 'api.telegram.org',
      path: `/bot${BOT_TOKEN}/sendMessage`,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(postData) }
    };
    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => resolve(body));
    });
    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

// Endpoint del formulario
app.post('/api/contacto', async (req, res) => {
  try {
    const { nombre, email, telefono, mensaje } = req.body;
    if (!nombre || !email || !mensaje) {
      return res.status(400).json({ success: false, message: 'Faltan campos obligatorios' });
    }
    
    const contacto = { nombre, email, telefono: telefono || 'No indicado', mensaje, fecha: new Date().toISOString() };
    contactosHoy.push(contacto);
    totalContactos++;
    
    await sendToTelegram(
      `📩 *Nuevo contacto desde la web*\n\n👤 *Nombre:* ${nombre}\n📧 *Email:* ${email}\n📞 *Teléfono:* ${telefono || 'No indicado'}\n💬 *Mensaje:* ${mensaje}`
    );
    
    console.log(`Contacto de ${nombre} (${email}) - Total hoy: ${contactosHoy.length}`);
    res.json({ success: true, message: 'Mensaje enviado correctamente. Te contactaremos pronto.' });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Error al enviar. Intentalo de nuevo.' });
  }
});

// Reporte diario a las 22:00 España (UTC+2 => 20:00 UTC)
cron.schedule('0 20 * * *', async () => {
  const fecha = new Date().toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const total = contactosHoy.length;
  
  let mensaje = `📊 *Reporte diario CFG - ${fecha}*\n\n`;

  if (total === 0) {
    mensaje += '❌ Hoy no se recibió ningún contacto desde la web.';
  } else {
    mensaje += `✅ *Total contactos hoy:* ${total}\n\n`;
    contactosHoy.forEach((c, i) => {
      mensaje += `${i+1}. *${c.nombre}* - ${c.email} ${c.telefono !== 'No indicado' ? '- ' + c.telefono : ''}\n`;
    });
  }
  mensaje += `\n📈 *Total histórico:* ${totalContactos}`;
  
  try {
    await sendToTelegram(mensaje);
    console.log(`Reporte diario enviado: ${total} contactos`);
    contactosHoy = []; // Reset contador diario
  } catch (err) {
    console.error('Error enviando reporte:', err.message);
  }
});

// Endpoint para ver estadísticas
app.get('/api/stats', (req, res) => {
  res.json({
    contactosHoy: contactosHoy.length,
    totalContactos: totalContactos,
    contactos: contactosHoy
  });
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', server: 'CFG Contacto API', contactosHoy: contactosHoy.length });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor CFG Contacto en puerto ${PORT}`);
  console.log(`Reporte diario programado a las 22:00 España`);
});
