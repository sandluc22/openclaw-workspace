#!/bin/bash
# Backup automático diario de todos los proyectos
# Se ejecuta a las 23:00 (hora del servidor, UTC)

WORKSPACE="/home/node/workspace"
BACKUP_DIR="$WORKSPACE/proyectos/BACKUPS"
FECHA=$(date +%Y-%m-%d)
LOG="$BACKUP_DIR/backup-log.txt"

mkdir -p "$BACKUP_DIR"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] === INICIO BACKUP DIARIO ===" >> "$LOG"

# Backup de cada proyecto
for PROYECTO in "CFG" "Club Contable" "Fiverr"; do
    PROY_PATH="$WORKSPACE/proyectos/$PROYECTO"
    if [ -d "$PROY_PATH" ]; then
        NOMBRE_ARCHIVO=$(echo "$PROYECTO" | sed 's/ /-/g')
        tar -czf "$BACKUP_DIR/${NOMBRE_ARCHIVO}-${FECHA}.tar.gz" \
            -C "$WORKSPACE/proyectos" "$PROYECTO" 2>/dev/null
        
        if [ $? -eq 0 ]; then
            echo "  ✅ $PROYECTO → ${NOMBRE_ARCHIVO}-${FECHA}.tar.gz" >> "$LOG"
        else
            echo "  ❌ $PROYECTO → ERROR" >> "$LOG"
        fi
    fi
done

# Backup del código fuente de CFG
if [ -d "$WORKSPACE/cfg-restauracion" ]; then
    tar -czf "$BACKUP_DIR/cfg-restauracion-${FECHA}.tar.gz" \
        -C "$WORKSPACE" "cfg-restauracion" 2>/dev/null
    if [ $? -eq 0 ]; then
        echo "  ✅ cfg-restauracion → cfg-restauracion-${FECHA}.tar.gz" >> "$LOG"
    fi
fi

# Limpiar backups antiguos (más de 30 días)
find "$BACKUP_DIR" -name "*.tar.gz" -mtime +30 -delete 2>/dev/null

echo "[$(date '+%Y-%m-%d %H:%M:%S')] === FIN BACKUP DIARIO ===" >> "$LOG"
echo "" >> "$LOG"

