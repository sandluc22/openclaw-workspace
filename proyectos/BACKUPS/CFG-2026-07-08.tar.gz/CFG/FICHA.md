# FICHA TÉCNICA - Crecimiento Financiero Global (CFG)

## 1. Dominio
- **URL:** crecimientofinancieroglobal.com
- **Registrador:** Porkbun
- **Caducidad:** 23-jun-2027 (auto-renovación activada)
- **Estado:** ✅ Funcionando

## 2. DNS
- **Gestionados por:** Cloudflare
- **NS en Porkbun:** chase.ns.cloudflare.com, sima.ns.cloudflare.com
- **Estado:** ✅ Activados (propagados globalmente)
- **Registros DNS en Cloudflare:** MX Migadu (correos), CNAME Surge/Netlify (web), TXT SPF/DKIM/DMARC

## 3. Hosting
- **Servicio actual:** Netlify
- **URL directa:** https://6a4d6f12b35ba94756643174--crecimientofinancieroglobal.netlify.app
- **SSL:** 🔄 Pendiente de activación (Cloudflare no ha emitido certificado aún - 7 jul)
- **Hosting anterior:** Surge (migrado a Netlify el 7-jul-2026)
- **Estado:** ✅ Desplegado con dominio personalizado crecimientofinancieroglobal.com

## 4. Correos
- **Gestor:** Migadu
- **Email principal:** info@crecimientofinancieroglobal.com ✅
- **Otros:** admin@, ventas@, administracion@, financiero@, director@
- **Estado:** ✅ Funcionando (MX en Cloudflare)

## 5. SEO
- **robots.txt:** ✅
- **sitemap.xml:** ✅
- **Google Search Console:** ✅ Verificado
- **Google Analytics:** ✅ GA4 (G-ZSXBB84TL3)
- **Indexación Google:** ❌ Pendiente de enviar sitemap (tras SSL activo)

## 6. Diseño
- **Estilo:** Oscuro azul marino
- **Logo:** Crecimiento (azul) · Financiero Global (amarillo)

## 7. Marketing de Afiliados
- **Programas pendientes:** Trade Republic (abrir cuenta para código referido)
- **Carpeta:** proyectos/CFG/Afiliados/AFILIADOS.md
- **Estado:** Pendiente de desarrollo

## 8. Historia de cambios
- **4-jul:** Configuración inicial, formulario, subpáginas
- **5-jul:** DNS a Migadu, correos, Instagram/LinkedIn
- **6-jul:** Restauración de subpáginas
- **7-jul:** Migración de Surge a Netlify. DNS de Migadu a Cloudflare (NS: chase/sima.cloudflare.com)
