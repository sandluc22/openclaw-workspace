# Credenciales Redes Sociales - Crecimiento Financiero Global

## Instagram
- **Usuario:** cfg.seguros
- **Contraseña:** AlfaySandra!
- **Correo asociado:** info@crecimientofinancieroglobal.com
- **Perfil visible:** https://instagram.com/cfg.seguros

## LinkedIn
- **Página empresa:** Crecimiento Financiero Global
- **URL:** https://linkedin.com/company/cfgseguros
- **Administrador:** sandluc22@gmail.com (cuenta personal de Sandra)
